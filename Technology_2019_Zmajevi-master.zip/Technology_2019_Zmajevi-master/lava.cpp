#include <bits/stdc++.h>

using namespace std;

int main()
{
	int lavas = 1;
	while (true)
	{
		int m, n, p;
		cin >> m >> n >> p;
		if (m == 0 && n == 0 && p == 0)
		{
			break;
		}
		char polje[100][100][20];
		for (int i = 0; i < p; i++)
		{
			for (int j = 0; j < m; j++)
			{
				for (int k = 0; k < n; k++)
				{
					cin >> polje[j][k][i];
				}
			}
		}

		list<std::tuple<int, int, int, int, int>> queue;

		queue.push_back(make_tuple(0, 0, 0, 0, 0));

		std::tuple<int, int, int, int, int> s;
		while (!queue.empty())
		{
			s = queue.front();
			queue.pop_front();

			std::cout << std::get<2>(s) << std::endl;

			if (std::get<2>(s) > m * n)
			{
				std::cout << lavas << ":-;";
				break;
			}

			if (std::get<0>(s) == m - 1 && std::get<1>(s) == n - 1)
			{
				std::cout << lavas << ":" << std::get<2>(s) << ";";
				break;
			}

			bool found = false;
			if (std::get<0>(s) - 1 > 0 && polje[std::get<0>(s) - 1][std::get<1>(s)][(std::get<2>(s) + 1) % p] != '#')
			{
				if (std::get<0>(s) != std::get<3>(s) || std::get<1>(s) != std::get<4>(s))
				{
					found = true;
					queue.push_back(make_tuple(std::get<0>(s) - 1, std::get<1>(s), std::get<2>(s) + 1, std::get<0>(s), std::get<1>(s)));
				}
			}
			if (std::get<0>(s) + 1 < m && polje[std::get<0>(s) + 1][std::get<1>(s)][(std::get<2>(s) + 1) % p] != '#')
			{
				if (std::get<0>(s) != std::get<3>(s) || std::get<1>(s) != std::get<4>(s))
				{
					found = true;
					queue.push_back(make_tuple(std::get<0>(s) + 1, std::get<1>(s), std::get<2>(s) + 1, std::get<0>(s), std::get<1>(s)));
				}
			}
			if (std::get<1>(s) - 1 > 0 && polje[std::get<0>(s)][std::get<1>(s) - 1][(std::get<2>(s) + 1) % p] != '#')
			{
				if (std::get<0>(s) != std::get<3>(s) || std::get<1>(s) != std::get<4>(s))
				{
					found = true;
					queue.push_back(make_tuple(std::get<0>(s), std::get<1>(s) - 1, std::get<2>(s) + 1, std::get<0>(s), std::get<1>(s)));
				}
			}
			if (std::get<1>(s) + 1 < n && polje[std::get<0>(s)][std::get<1>(s) + 1][(std::get<2>(s) + 1) % p] != '#')
			{
				if (std::get<0>(s) != std::get<3>(s) || std::get<1>(s) != std::get<4>(s))
				{
					found = true;
					queue.push_back(make_tuple(std::get<0>(s), std::get<1>(s) + 1, std::get<2>(s) + 1, std::get<0>(s), std::get<1>(s)));
				}
			}
			if (!found && polje[std::get<0>(s)][std::get<1>(s)][(std::get<2>(s) + 1) % p] != '#')
			{
				queue.push_back(make_tuple(std::get<0>(s), std::get<1>(s), std::get<2>(s) + 1, -1, -1));
			}
		}
		lavas++;
	}
	std::cout << std::endl;
}
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Prime {

    public static int lucas(int n) {

        int a = 2, b = 1, c, i;

        if (n == 0) return a;

        for (i = 2; i <= n; i++)
        {
            c = (a % 1000000000 + b % 1000000000) % 1000000000;
            a = b;
            b = c;
        }
        return b;
    }

    public static void main(String[] args) {

        for (int f = 0; f < 10; f++) {
            List<String> lines = new ArrayList<>();
            try {
                lines = Files.readAllLines(Paths.get("C:\\Users\\triof\\Desktop\\" +
                        "moje_stvari\\5. godina\\STEMZadaci\\prime\\" + f + ".in"));
            } catch (IOException e) {
                e.printStackTrace();
            }

            int m = Integer.parseInt(lines.get(0));

            int x = 0;
            for (int i = m + 1; i < 2*m; i++) {
                boolean isPrime = true;
                for (int j = 2; j <= Math.round(Math.sqrt(i)); j++) {
                    if (i % j == 0) {
                        isPrime = false;
                        break;
                    }
                }

                if (isPrime)  {
                    x = i;
                    break;
                }
            }

            System.out.println(lucas(x));
        }

    }


}

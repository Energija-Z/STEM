import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class Cities {

    public static Map<Integer, List<Integer>> neighbours;

    public static boolean[] visited;

    public static class Pair {

        public int first;
        public int second;

        public Pair(int first, int second) {
            this.first = first;
            this.second = second;
        }
    }

    public static void main(String[] args) {

        //Scanner sc = new Scanner(System.in);

        //String[] first = sc.nextLine().split(" ");

        for (int f = 4; f < 10; f++) {
            List<String> lines = new ArrayList<>();
            try {
                 lines = Files.readAllLines(Paths.get("C:\\Users\\triof\\Desktop\\" +
                        "moje_stvari\\5. godina\\STEMZadaci\\cities\\" + f + ".in"));
            } catch (IOException e) {
                e.printStackTrace();
            }

            String[] first = lines.get(0).split(" ");
            int m = Integer.parseInt(first[0]);
            int n = Integer.parseInt(first[1]);
            int k = Integer.parseInt(first[2]);

            neighbours = new HashMap<>();

            List<Pair> roads = new ArrayList<>();

            for (int i=0; i<n; i++) {
                //String[] connection = sc.nextLine().split(" ");
                String[] connection = lines.get(i + 1).split(" ");

                int a = Integer.parseInt(connection[0]);
                int b = Integer.parseInt(connection[1]);

                List<Integer> neighbourList = (neighbours.get(a) == null ? new ArrayList<>() : neighbours.get(a));
                neighbourList.add(b);
                neighbours.put(a, neighbourList);

                neighbourList = (neighbours.get(b) == null ? new ArrayList<>() : neighbours.get(b));
                neighbourList.add(a);
                neighbours.put(b, neighbourList);

                roads.add(new Pair(a, b));
            }

            int[] removals = new int[k];
            for (int i = 0; i < k; i++) {
                //removals[i] = Integer.parseInt(sc.nextLine());
                removals[i] = Integer.parseInt(lines.get(n + 1 + i));
            }

            int groupsSum = 0;
            for (int i = -1; i < k; i++) {

                if (i != -1) {
                    Pair road = roads.get(removals[i]);
                    neighbours.get(road.first).remove((Integer)road.second);
                    neighbours.get(road.second).remove((Integer)road.first);
                }

                visited = new boolean[m];

                int groupsNum = 0;
                for (int j = 0; j < m; j++) {
                    if (!visited[j]) {
                        groupsNum++;
                        Stack<Integer> stack = new Stack<>();
                        stack.push(j);
                        while (!stack.empty()) {
                            int v = stack.pop();
                            visited[v] = true;

                            if (neighbours.get(v) == null) continue;

                            for (Integer nn : neighbours.get(v)) {
                                if (!visited[nn]) {
                                    stack.push(nn);
                                }
                            }
                        }
                    }
                }

                groupsSum += groupsNum;
            }

            System.out.printf("%.2f\n", groupsSum * 1.0/(k + 1));
        }

    }
}
